/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_182(unsigned x)
{
    return x + 2445773128U;
}

unsigned getval_407()
{
    return 3762209624U;
}

unsigned getval_225()
{
    return 2425393752U;
}

void setval_454(unsigned *p)
{
    *p = 2428993864U;
}

unsigned addval_455(unsigned x)
{
    return x + 2592523032U;
}

unsigned getval_406()
{
    return 3277332580U;
}

void setval_449(unsigned *p)
{
    *p = 2428995912U;
}

unsigned addval_338(unsigned x)
{
    return x + 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_181(unsigned x)
{
    return x + 3286272330U;
}

unsigned addval_312(unsigned x)
{
    return x + 3523791497U;
}

unsigned getval_281()
{
    return 3674789385U;
}

void setval_376(unsigned *p)
{
    *p = 3678980745U;
}

void setval_482(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_438(unsigned x)
{
    return x + 2430634312U;
}

void setval_189(unsigned *p)
{
    *p = 3674784137U;
}

unsigned getval_498()
{
    return 3381971593U;
}

void setval_480(unsigned *p)
{
    *p = 3376993929U;
}

unsigned addval_429(unsigned x)
{
    return x + 3599348712U;
}

unsigned getval_322()
{
    return 3380920717U;
}

unsigned getval_134()
{
    return 3531915657U;
}

unsigned getval_101()
{
    return 2430632264U;
}

void setval_383(unsigned *p)
{
    *p = 3183722891U;
}

unsigned getval_408()
{
    return 3221804713U;
}

unsigned getval_491()
{
    return 3532964233U;
}

unsigned getval_197()
{
    return 3229931145U;
}

unsigned getval_230()
{
    return 3281174921U;
}

unsigned addval_303(unsigned x)
{
    return x + 2425411081U;
}

unsigned addval_453(unsigned x)
{
    return x + 2445969668U;
}

void setval_186(unsigned *p)
{
    *p = 3286272328U;
}

void setval_262(unsigned *p)
{
    *p = 3682915969U;
}

void setval_111(unsigned *p)
{
    *p = 3674262153U;
}

unsigned addval_163(unsigned x)
{
    return x + 3281049229U;
}

void setval_191(unsigned *p)
{
    *p = 3527985801U;
}

unsigned getval_127()
{
    return 2429159757U;
}

unsigned getval_359()
{
    return 2462157186U;
}

void setval_112(unsigned *p)
{
    *p = 3286288712U;
}

unsigned getval_401()
{
    return 3252717896U;
}

unsigned addval_341(unsigned x)
{
    return x + 3247489417U;
}

unsigned addval_364(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_404()
{
    return 2425408137U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
